# whimsilogical.com

The Whimsilogical website — a plain HTML/CSS site (no build step, no framework).
Built to use the VS Code + Live Preview workflow.

## Files

```
whimsilogical/
├── index.html      ← Home page
├── apps.html       ← Apps (live + on the horizon)
├── writing.html    ← Essay index
├── about.html      ← Founder story + philosophy + contact
├── styles.css      ← ALL the styling lives here (colors, fonts, layout)
├── netlify.toml    ← Tells Netlify how to publish (no build needed)
└── essays/
    └── before-the-harm-is-done.html  ← Essay 1 (paste your text in)
```

## How to preview it (VS Code)

1. Open this folder in VS Code (File → Open Folder).
2. Right-click `index.html` → "Open with Live Server" (or use the Go Live button).
3. Click the nav links to move between pages.

## How to change things (the common ones)

**Colors and fonts:** all at the very top of `styles.css`, in the `:root` block.
Change a value once there and every page updates.

**The contact email:** currently `hellowhimsilogical@gmail.com`. To change it,
do a Find & Replace across all files (Ctrl/Cmd+Shift+F) for that address.

**Add your Essay 1 text:** open `essays/before-the-harm-is-done.html`, find the
big comment block, and paste your paragraphs between the `<p>` tags as instructed.

**Vesper:** her spot is reserved in the hero (the dashed circle, top-right).
When she's designed, replace the `.vesper-spot` div in `index.html` with her image.

## How to deploy to Netlify

Same as your other apps: drag this whole folder onto the Netlify dashboard,
or connect it via GitHub. No build command, no publish directory to set —
`netlify.toml` handles it. Then point whimsilogical.com at the new site
in Netlify's domain settings.

## Future: migrating to Astro

When your class covers the terminal and npm, this can move to Astro for
easier essay management (Markdown instead of HTML) and shared layouts.
The content all carries over. No rush.
